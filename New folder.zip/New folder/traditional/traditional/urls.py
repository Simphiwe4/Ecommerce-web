"""
URL configuration for traditional project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.conf import settings
from django.contrib import admin
from django.conf.urls.static import static
from django.contrib.auth import views
from django.urls import path,include
from cart.views import add_to_cart,cart,checkout,hx_menu_cart,update_cart
from core.views import frontpage,shop, signup,myaccount, edit_myaccount
from products.views import product


urlpatterns = [
    path('',frontpage, name='frontpage'),
    path('signup/',signup, name='signup'),
    path('logout/',views.LogoutView.as_view(next_page='/'),name='logout'),
    path('login/',views.LoginView.as_view(template_name='core/login.html'), name='login'),
    path('cart/',cart, name='cart'),
    path('shop/',shop, name='shop'),
    path('myaccount/',myaccount,name='myaccount'),
    path('myaccount/edit/',edit_myaccount,name='edit_myaccount'),
    path('hx_menu_cart/',hx_menu_cart,name='hx_menu_cart'),
    path('checkout/',checkout, name='checkout'),
    path('product/<slug:slug>/', product, name='product'),
    path('shop/<slug:slug>/',product, name='product'),
    path('add_to_cart/<int:product_id>/', add_to_cart , name='add_to_cart'),
    path('update_cart/<int:product_id>/<str:action>/',update_cart, name='update_cart'),
    path('admin/', admin.site.urls),
    path('order/', include('order.urls'))
] + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
